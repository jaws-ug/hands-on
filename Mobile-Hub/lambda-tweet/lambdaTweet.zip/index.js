'use strict';
var Twitter = require('twitter');

var client = new Twitter({
  consumer_key: 'pttdSwH1RY5tWwQSaaB3iAcKR',
  consumer_secret: 'eFeDqoZ1RiQV1EtwWj9xj1t933kcDqWc2zyA7dBJgP0WRA8n2b',
  access_token_key: '4742259560-ARJUJDNRzEaazntBSPsTMESkNeh1eF3UedRjH0r',
  access_token_secret: 'Pkg9lbYk5WqvfiL5Rl9EFNtzaC2whVCfM7ZpYc2fOa0x0'
});

exports.handler = function(event, context) {
    console.log(JSON.stringify(event, null, 2));
    console.log(JSON.stringify(context, null, 2));

    var postMessage = 'We love AWS!';
    if (event.tweet) {
        postMessage = event.tweet;
    }
    client.post('statuses/update', {status: postMessage},  function(error, tweet, response){
        if (error) {
            console.log(error);
            context.done('error getting object', error);
        } else {
            console.log(tweet);
            context.succeed(postMessage);
        }
    });
};


